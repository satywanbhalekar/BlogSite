@extends('layouts.main')
@push('Title')
<title> about </title>
@endpush

@section('main-section')


<h1 class="text-center">About page</h1>
@endsection 