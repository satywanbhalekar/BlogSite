@extends('layouts.main')

@push('Title')
    <title> View </title>
@endpush

@section('main-section')
    <div class="container mt-4">
        <div class="row">
            @foreach($customer as $customer)
                <div class="col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title">{{ $customer->title }}</h5>
                            <p class="card-text">Date of Birth: {{ $customer->dob }}</p>
                            <p class="card-text">Message: 
                                @if(str_word_count($customer->massage) > 30)
                                    {{ substr($customer->massage, 0, strpos($customer->massage, ' ', 30)) }}...
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#readMoreModal{{ $customer->customer_id }}">Read More</a>
                                    <div class="modal fade" id="readMoreModal{{ $customer->customer_id }}" tabindex="-1" aria-labelledby="readMoreModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="readMoreModalLabel">{{ $customer->title }}</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>{{ $customer->massage }}</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @else
                                    {{ $customer->massage }}
                                @endif
                            </p>
                            <p class="card-text">Status: 
                                @if($customer->status == "1")
                                    <span class="badge bg-success">Active</span>
                                @else
                                    <span class="badge bg-danger">InActive</span>
                                @endif
                            </p>
                            <a href="/register/edit/{{ $customer->customer_id }}" class="btn btn-primary">Edit</a>
                            <a href="/register/delete/{{ $customer->customer_id }}" class="btn btn-danger">Delete</a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection
