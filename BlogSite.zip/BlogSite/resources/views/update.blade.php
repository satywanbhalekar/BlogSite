@extends('layouts.main')
@push('Title')
<title>{{$title}}</title>
@endpush

@section('main-section')




<!doctype html>
<html lang="en">

<head>
<!-- <title>Title</title> -->
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">

</head>

<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <form action="/register/edituser/{{$user->id}}" method="post">
        @csrf
      
  <div class="container d-block mt-4 ">

    <div class="row mx-auto ">
    <div class="mb-3 col-md-6 required justify-content-center">
      <label for="" class="form-label">name</label require>
      <input type="text" class="form-control" name="name" id="name" aria-describedby="emailHelpId" placeholder=" " value="{{$user->name}}" >
      <span class="text-danger">
        @error('name')
        {{$message}}
        @enderror
      </span>
    </div>
    <div class="mb-3 col-md-6 required  justify-content-center">
      <label for="" class="form-label">Email</label>
      <input type="email" class="form-control" name="email" id="Email"  aria-describedby="emailHelpId" placeholder="" value="{{$user->email}}">
      <span class="text-danger">
        @error('email')
        {{$message}}
        @enderror
      </span>
    </div>
    <div class="mb-3 col-md-6 required  justify-content-center">
      <label for="" class="form-label">Password</label>
      <input type="password" class="form-control" name="password" id="password"  aria-describedby="emailHelpId" placeholder="">
    </div>
   



    <button class="btn btn-primary" >UPDATE</button>
  </div>
  </form>


  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
</body>

</html>
@endsection 