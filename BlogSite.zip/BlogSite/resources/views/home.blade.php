@extends('layouts.main')

@push('Title')
<title> home </title>
@endpush

@section('main-section')

<!-- <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://source.unsplash.com/random/1920x800/?micorosft,engineer" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://source.unsplash.com/random/1920x800/?laptop,landscape" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://source.unsplash.com/random/1920x800/?ironman,landscape" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div> -->
<!--     
    <div class="carousel-item">
      <img src="https://images.unsplash.com/photo-1518384491952-3f4731b5f9cd?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60" class="d-block w-100" alt="The developer is an asshole and didn't want to help you, I'm sorry about that.">
    </div> -->
    

    <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Notebook Cloud Home</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.1/css/bootstrap.min.css">
</head>
<body>
  
  <div class="container-fluid">
    <div class="row justify-content-center text-center" >
      <div class="col-lg-12 col-md-12  mt-4">
        <h1>Notebook Cloud</h1>
        <p>Store and access your notes and ideas from anywhere, anytime.</p>
        <a href="{{url("register/create")}}" class="btn btn-primary">Add Notes</a>
      </div>
      <div class="col-lg-12 col-md-12 justify-content-center mt-4">
        <div class="card">
          <img class="card-img-top" id="bgImage" src="" alt="Random Background Image">
          <div class="card-body">
            <h5 class="card-title">Explore Our Features</h5>
            <p class="card-text">Check out our amazing features and see how Notebook Cloud can help you organize your thoughts and streamline your workflow.</p>
            <a href="#" class="btn btn-secondary">Learn More</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.1/js/bootstrap.min.js"></script>
  <script>
    $(function() {
      // Get a random background image from Unsplash
      $.getJSON("https://source.unsplash.com/random", function(data) {
        $("#bgImage").attr("src", data.urls.regular);
      });
    });
  </script>
</body>
</html>




@endsection 