@include('layouts.header')
<div class="container">
    @yield('main-section')
</div>
@include('layouts.footer')