@extends('layouts.main')
@push('title')
<title>View</title>
@endpush

@section('main-section')

<div class="table-responsive">
  <table class="table table-primary">
    <thead>
      <tr>
        <th scope="col">Name</th>
        <th scope="col">DOB</th>
        <th scope="col">Massage</th>
        <th scope="col">Status</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      @if(!is_null($customer))
        <tr class="">
          <td scope="row">{{$customer->title}}</td>
          <td>{{$customer->dob}}</td>
          <td>{{$customer->massage}}</td>
          <td>
            @if($customer->status == "1")
              <span class="badge bg-success ">Active</span>
            @else
              <span class="badge bg-danger">InActive</span>
            @endif
          </td>
          <td>
            <button type="button" class="btn btn-primary btn-sm d-inline-block m-2 mb-4 mt-0 float-right" data-toggle="modal" data-target="#exampleModal">
              View More
            </button>
            <a class="btn btn-primary btn-sm d-inline-block m-2 mb-4 mt-0 float-right " href="/register/delete/{{$customer->customer_id}}" role="button">Delete </a>
            <a class="btn btn-primary btn-sm d-inline-block m-2 mb-4 mt-0 float-right " href="/register/create" role="button">Add </a>
            <a class="btn btn-primary btn-sm d-inline-block m-2 mb-4 mt-0 float-right " href="/register/edit/{{$customer->customer_id}}" role="button">Edit </a>
          </td>
        </tr>
      @endif
    </tbody>
  </table>
</div>

<!-- Bootstrap JavaScript Libraries -->
<script src="{{ asset('js/jquery.min.js') }}"></script>
<script src="{{ asset('js/bootstrap.min.js') }}"></script>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{$customer->title}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>{{$customer->dob}}</p>
        <p>{{$customer->massage}}</p>
        <p>
          @if($customer->status == "1")
            <span class="badge bg-success ">Active</span>
          @else
            <span class="badge bg-danger">InActive</span>
          @endif
        </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

@endsection
