
<?php $__env->startPush('Title'); ?>
<title> Add Blog Post </title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>




<!doctype html>
<html lang="en">

<head>
  <title>Title</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <head>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.min.js"></script>
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.1/themes/smoothness/jquery-ui.css">
</head>


</head>
<form action="/register/" method="post">
        <?php echo csrf_field(); ?>

<body>
<div class="container">
<div class="container ">
  <div class="row">
    <div class="col-md-12 text-center">
      <h1>Add Blog Post</h1>
    </div>
  </div>
  <div class="row d-flex justify-content-center">
    <div class="col-md-5">
      <div class="mb-3">
        <label for="title" class="form-label">Title</label>
        <input type="text" class="form-control" name="title" id="title">
        <span class="text-danger">
          <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
      </div>
    </div>
  </div>
  <div class="row d-flex justify-content-center">
    <div class="col-md-5 ">
      <div class="mb-3">
        <label for="massage" class="form-label">Massage</label>
        <textarea class="form-control" style="height: 252px;" name="massage" id="massage"></textarea>
        <span class="text-danger">
          <?php $__errorArgs = ['massage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
      </div>
    </div>
  </div>
  <div class="row d-flex justify-content-center">
    <div class="col-md-5 ">
      <div class="mb-3">
        <label for="date" class="form-label">Date</label>
        <input type="text" class="form-control datepicker"  name="dob" id="date" placeholder="yyyy-mm-dd">
        <span class="text-danger">
          <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
      </div>
    </div>
  </div>
  <div class="row ">
    <div class="col-md-12 d-flex justify-content-center mt-4">
      <button class="btn btn-primary">Add Post</button>
    </div>
  </div>
</div>

</div>


  <script>
  $(function() {
    $("#date").datepicker({
      dateFormat: "yy-mm-dd", // format the date as yyyy-mm-dd
      changeYear: true, // allow the user to select the year
      yearRange: "-100:+0" // allow the user to select a year up to 100 years ago
    });
  });
</script>

  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
</body>

</html>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\BlogSite\resources\views/form.blade.php ENDPATH**/ ?>