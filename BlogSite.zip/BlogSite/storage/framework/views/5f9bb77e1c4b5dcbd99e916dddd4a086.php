
<?php $__env->startPush('Title'); ?>
<title><?php echo e($title); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>




<!doctype html>
<html lang="en">

<head>
<!-- <title>Title</title> -->
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">

</head>

<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <form action="/register/edit/<?php echo e($customer->customer_id); ?>" method="post">
        <?php echo csrf_field(); ?>
      
  <div class="container">

    <div class="row mt-4">
    <div class="mb-3 col-md-5 required">
      <label for="" class="form-label">Title</label require>
      <input type="text" class="form-control" name="title" id="name" aria-describedby="emailHelpId" placeholder=" " value="<?php echo e($customer->title); ?>" >
      <span class="text-danger">
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </span>
    </div>
    
    <div class="mb-3 col-md-5 required">
      <label for="" class="form-label">Massage</label>
      <input type="text" class="form-control" name="massage" id="massage"  aria-describedby="emailHelpId" placeholder="" value="<?php echo e($customer->massage); ?>">
      <span class="text-danger">
        <?php $__errorArgs = ['Massage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </span>
    </div>
   
   
    

</div>
<div class="mb-3 col-md-5 required required">
  <label for="date" class="form-label">Date</label>
  <input type="text" class="form-control datepicker" name="dob" id="date" aria-describedby="emailHelpId" placeholder="" value="<?php echo e($customer->dob); ?>">
  <span class="text-danger">
    <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <?php echo e($message); ?>

    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </span>
</div>



    <button class="btn btn-primary" >UPDATE</button>
  </div>
  </form>
  <script>
  $(function() {
    $("#date").datepicker({
      format: "yyyy-mm-dd", // format the date as yyyy-mm-dd
      startView: 2, // show the year and month first
      autoclose: true, // close the date picker when a date is selected
      todayHighlight: true, // highlight the current date
      orientation: "bottom" // display the date picker below the input field
    });
  });
</script>

  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
</body>

</html>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\BlogSite\resources\views/updateform.blade.php ENDPATH**/ ?>