
<?php $__env->startPush('Title'); ?>
<title> View </title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-section'); ?>


<!doctype html>
<html lang="en">

<head>
  <title>Title</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

</head>

<body>

  <div class="table-responsive">
    
    <table class="table table-primary">
        <thead>
            <tr>
                <th scope="col">Name</th>
                <th scope="col">Email</th> 
                <th scope="col">Password</th>
                <th scope="col">Action</th>
                
            </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <tr class="">
               
                <td scope="row"><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                
               
                <td><?php echo e($user->password); ?></td>
               
                <td>
                <a class="btn btn-primary btn-sm d-inline-block m-2 mb-4 mt-0 float-right " href="/register/delete/<?php echo e($user->id); ?>" role="button">Delete </a>
                <a class="btn btn-primary btn-sm d-inline-block m-2 mb-4 mt-0 float-right " href="/register/create" role="button">Add </a>
                <a class="btn btn-primary btn-sm d-inline-block m-2 mb-4 mt-0 float-right " href="/register/edituser/<?php echo e($user->id); ?>" role="button">Edit </a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
  </div>
  
  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
</body>

</html>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\BlogSite\resources\views/customerupdate.blade.php ENDPATH**/ ?>