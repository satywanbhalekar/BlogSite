

<?php $__env->startPush('Title'); ?>
    <title> View </title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
    <div class="container mt-4">
        <div class="row">
            <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($customer->title); ?></h5>
                            <p class="card-text">Date of Birth: <?php echo e($customer->dob); ?></p>
                            <p class="card-text">Message: 
                                <?php if(str_word_count($customer->massage) > 30): ?>
                                    <?php echo e(substr($customer->massage, 0, strpos($customer->massage, ' ', 30))); ?>...
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#readMoreModal<?php echo e($customer->customer_id); ?>">Read More</a>
                                    <div class="modal fade" id="readMoreModal<?php echo e($customer->customer_id); ?>" tabindex="-1" aria-labelledby="readMoreModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="readMoreModalLabel"><?php echo e($customer->title); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><?php echo e($customer->massage); ?></p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <?php echo e($customer->massage); ?>

                                <?php endif; ?>
                            </p>
                            <p class="card-text">Status: 
                                <?php if($customer->status == "1"): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">InActive</span>
                                <?php endif; ?>
                            </p>
                            <a href="/register/edit/<?php echo e($customer->customer_id); ?>" class="btn btn-primary">Edit</a>
                            <a href="/register/delete/<?php echo e($customer->customer_id); ?>" class="btn btn-danger">Delete</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\BlogSite\resources\views/customer-view.blade.php ENDPATH**/ ?>