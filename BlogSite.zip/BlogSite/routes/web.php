<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RegistrationController;
use App\Http\Controllers\CustomerController;
use App\Models\Customer;
use App\Http\Controllers\CustomAuthController;
use App\Models\Users;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/register/create',[RegistrationController::class,'create']);
Route::post('/register/',[RegistrationController::class,'register']);
Route::get('/register/view',[RegistrationController::class,'view']);



Route::get('/register/delete/{id}',[RegistrationController::class,'delete']);
Route::get('/register/edit/{id}',[RegistrationController::class,'edit']);
Route::post('/register/edit/{id}',[RegistrationController::class,'update']);


Route::get('/register/edituser/{id}',[RegistrationController::class,'edituser']);
Route::post('/register/edituser/{id}',[RegistrationController::class,'updateuser']);


Route::get('about',[RegistrationController::class,'about'])->name('about')->middleware('auth');//important middelware 
Route::Resource('/photo',PhotoController::class);
Route::get('dashboard', [CustomAuthController::class, 'dashboard']); 
Route::get('/', [CustomAuthController::class, 'index'])->name('login');
Route::post('postlogin', [CustomAuthController::class, 'login'])->name('postlogin'); 
Route::get('signup', [CustomAuthController::class, 'signup'])->name('register-user');
Route::post('postsignup', [CustomAuthController::class, 'signupsave'])->name('postsignup'); 
Route::get('signout', [CustomAuthController::class, 'signOut'])->name('signout');
