<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;


use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Users;

class RegistrationController extends Controller
{


   public function create()
   {
    if(Auth::check()){
        return view('form');
    }
    return redirect('/');
    // $url = url("/register/");
    $title = "Customer Registration";
    $data = compact('title');
    return view('form')->with($data);
    
   }
   public function register(Request $request)
   {
    $request->validate(
        [
            'title' => 'required',
            
            'massage'=> 'required',
           
            'dob' => 'required'
        ]
        );

//     echo "<pre>";
//    print_r($request->all());
//    Insert query
   $customer = new Customer;
   $customer->title = $request['title'];
   
   $customer->dob= $request['dob'];
   $customer->massage= $request['massage'];
   $customer->save();
   return redirect('/register/view');
   //-------
   }
   public function view()
   {
    
    // // Retrieve the authenticated user's email and name
    // $email = auth()->user()->email;
    // $name = auth()->user()->name;
    
    // // Retrieve only the customers associated with the authenticated user's email and name
    // $customer = Customer::where('email', $email)
    //     ->where('name', $name)
    //     ->get();
    
    // $data = compact('customer');
    // return view('customer-view')->with($data);
    
   
         $customer = Customer::all();
        
    // echo($customer);
    $data = compact('customer');
    return view('customer-view')->with($data);
   }


   public function delete($id)
   {
    //   echo $id;
    //   die;
    $customer = Customer::find($id);
        if(!is_null($customer))
        {
            $customer->delete();
        }
    return redirect("register/view");
    // echo"<pre>";
    // print_r($customer);
   }
   public function edit($id)
   {
    $customer = Customer::find($id);
    if(is_null($customer))
    {
      //not fonund
      return redirect("register/view");
   }else{
     //found 
     $title = "Update Customer";
    //  $url = url('/register/update/') . "/" . $id;
    //  $data = compact('customer','url','title');
     $data = compact('customer','title');
     return view('updateform')->with($data);

   }
}
public function about()
{
    if(Auth::check()){
        return view('about');
    }
    return redirect('/');  
}
 
public function update($id, Request $request)
{
    $customer = Customer::find($id);  
    $customer->title = $request['title'];
   

    $customer->massage= $request['massage'];
    
    $customer->dob= $request['dob'];
    $customer->save();
    return redirect('register/view');
}
 
public function updateuser($id, Request $request)
{
    $user = Users::find(1);  
    $user->name = $request['name'];
    $user->email= $request['email'];
    if ($request->filled('password')) {  // only update password if provided
        $user->password = bcrypt($request->input('password'));
    }

    $user->save();
    $msg="profile updated";
    $data = compact('msg','user');
    return redirect('register/view')->with($data);
}


public function edituser($id)
   {
    $user = Users::find(1);
    if(is_null($user))
    {
      //not fonund
      return redirect("register/view");
   }else{
     //found 
     $title = "Update Customer";
    //  $url = url('/register/update/') . "/" . $id;
    //  $data = compact('customer','url','title');
     $data = compact('user','title');
     return view('update')->with($data);

   }
}
}